import ClientHome from "./ClientHome";

export default function Home() {
  return <ClientHome />;
}
